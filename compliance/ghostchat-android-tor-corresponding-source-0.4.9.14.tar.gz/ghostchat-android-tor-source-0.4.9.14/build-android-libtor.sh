#!/usr/bin/env bash
set -euo pipefail

root_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
external_dir="$root_dir/guardian-project/external"
tor_archive="$root_dir/sources/tor-0.4.9.14.tar.gz"
expected_tor_sha=182449ac1c8ff43278da27b69b02040e11d03d0327db6d9126e4190ec6235e4a
expected_ndk=30.0.16248370

: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME to NDK $expected_ndk}"
: "${JAVA_HOME:?Set JAVA_HOME to a Java 25 JDK}"
actual_ndk=$(sed -n 's,^Pkg.Revision *= *\([^ ]*\),\1,p' "$ANDROID_NDK_HOME/source.properties")
if [[ "$actual_ndk" != "$expected_ndk" ]]; then
  printf 'Expected NDK %s; found %s\n' "$expected_ndk" "${actual_ndk:-missing revision}" >&2
  exit 1
fi
actual_tor_sha=$(sha256sum "$tor_archive" | awk '{print $1}')
if [[ "$actual_tor_sha" != "$expected_tor_sha" ]]; then
  printf 'Tor source SHA-256 mismatch: %s\n' "$actual_tor_sha" >&2
  exit 1
fi

if [[ ! -f "$external_dir/tor/configure.ac" ]]; then
  tar -xzf "$tor_archive" -C "$external_dir"
  mv "$external_dir/tor-0.4.9.14" "$external_dir/tor"
fi
grep -Fq 'AC_INIT([tor],[0.4.9.14])' "$external_dir/tor/configure.ac"

export ANDROID_NDK_HOME JAVA_HOME
make -C "$external_dir" -f build-tools
APP_ABI=arm64-v8a make -C "$external_dir"

out_file=${1:-"$root_dir/build-output/libtor.so"}
mkdir -p "$(dirname -- "$out_file")"
install -m 0644 "$external_dir/lib/arm64-v8a/libtor.so" "$out_file"
llvm_readelf="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf"
llvm_nm="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-nm"
"$llvm_readelf" -h "$out_file" | grep -Fq 'AArch64'
for symbol in \
  tor_main_configuration_new \
  tor_main_configuration_set_command_line \
  tor_main_configuration_free \
  tor_run_main \
  tor_api_get_provider_version; do
  "$llvm_nm" -D --defined-only "$out_file" | awk '{print $NF}' | grep -Fxq "$symbol"
done
sha256sum "$out_file"
printf 'Built ARM64 Tor 0.4.9.14: %s\n' "$out_file"
