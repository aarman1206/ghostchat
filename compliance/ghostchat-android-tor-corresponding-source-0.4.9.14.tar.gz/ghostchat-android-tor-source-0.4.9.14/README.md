# Build the GhostChat Android Tor runtime

This source package contains the pinned Guardian build recipe and dependency
sources plus the official Tor 0.4.9.14 source tarball, checksum and signature.
It does not contain a prebuilt Tor binary or the user-provided Tor Browser APK.

Requirements: Linux x86_64, Java 25, Android NDK `30.0.16248370`, GNU make,
Perl, Autoconf/Automake/Libtool, pkg-config, and standard compiler utilities.
Set `JAVA_HOME` to the JDK 25 directory and `ANDROID_NDK_HOME` to that exact
NDK revision. The Guardian recipe builds static OpenSSL 3.5.9, libevent 2.1.13,
zlib 1.3.2 and zstd 1.5.7, then links the Tor 0.4.9.14 Android ARM64 library.

From this directory:

```sh
export JAVA_HOME=/path/to/jdk-25
export ANDROID_NDK_HOME=/path/to/Android/Sdk/ndk/30.0.16248370
./build-android-libtor.sh /path/to/output/libtor.so
```

The included Guardian recipe has two small GhostChat-specific build fixes:
it uses the `configure` script shipped in the official Tor release archive,
and it enables Tor's `-rdynamic` linker flag for the JNI embedding API. The
upstream `-rdynamic` feature probe is a false negative with the NDK's
`-Werror -Wstrict-prototypes` flags because its probe uses an old-style
`main()` declaration. The recipe now rejects the build unless all five public
embedding symbols used by GhostChat's JNI bridge appear in the dynamic symbol
table. The exact recipe changes are in `patches/`.
For the GhostChat app, copy the resulting library to
`app/src-tauri/gen/android/app/src/main/jniLibs/arm64-v8a/libtor.so`, then run
the Tauri Android APK/AAB build. The bridge itself is compiled by Android Gradle.
